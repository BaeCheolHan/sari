# 통합 ERD

> 전체 workspace의 데이터 관계도

## 사용법
- repo별 ERD: `docs/<repo>/erd/<api-name>.md`
- 여기는 cross-repo 통합 뷰
