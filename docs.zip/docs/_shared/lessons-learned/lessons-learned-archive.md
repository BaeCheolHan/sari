# 교훈 아카이브

> 오래된 교훈 보관. 활성 교훈은 `lessons-learned.md` 참조.
