# 교훈 (Lessons Learned)

> 태그 기반 검색. 한 엔트리에 2~4개 태그.

## 형식
```
[YYYY-MM-DD] [tag1][tag2] 교훈 1~2줄
```

[2026-01-30] [process][docs] 버전 표기 위치는 VERSIONING.md를 기준으로 정리해 누락 위험을 줄인다.
[2026-01-30] [tools][msa] 인덱싱 범위 변경 시 exclude_dirs와 루트 repo 처리까지 함께 갱신한다.
[2026-01-30] [tools][ops] 캐시 경로 변경 시 마이그레이션/언인스톨 경로를 같이 갱신한다.
[2026-01-30] [process][ux] install.sh 단독 실행을 지원하고, rules 덮어쓰기 여부를 명확히 묻는다.
