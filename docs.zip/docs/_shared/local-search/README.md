# Local Search (포인터)

> 정본: `.codex/tools/local-search/README.md`

v2.3.0부터 MCP로 통합. `.codex/config.toml`의 `[mcp_servers.local-search]` 설정 참조.
