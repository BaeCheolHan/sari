@RestController
@RequestMapping("/new")
public class New {}