import sys
import os
from pathlib import Path

# --- GLOBAL PURIFICATION: Force environment consistency ---
SARI_ROOT = str(Path(__file__).resolve().parents[1])
if SARI_ROOT not in sys.path:
    sys.path.insert(0, SARI_ROOT)

# Ensure sub-processes and dynamic imports can find modernized dependencies
os.environ["PYTHONPATH"] = f"{SARI_ROOT}:{os.environ.get('PYTHONPATH', '')}"

from .version import __version__
