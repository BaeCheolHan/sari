import sqlite3
import logging
import time
import zlib
import threading
from typing import List, Dict, Any, Optional, Iterable, Tuple

try:
    from peewee import SqliteDatabase, fn, CompositeKey, ForeignKeyField, Proxy, Model, CharField, TextField, IntegerField, BigIntegerField, BlobField, AutoField
    from .models import database_proxy, Root, File, Symbol, FailedTask, Snippet, Context
    HAS_PEEWEE = True
except ImportError:
    HAS_PEEWEE = False
    class SqliteDatabase:
        def __init__(self, *args, **kwargs): pass
        def connect(self, **kwargs): pass
        def atomic(self):
            class Atom:
                def __enter__(self): return self
                def __exit__(self, *args): pass
            return Atom()
    def fn(*args): pass
    database_proxy = None

from .schema import init_schema

class LocalSearchDB:
    def __init__(self, db_path: str, logger=None):
        self.db_path = db_path
        self.logger = logger or logging.getLogger("sari.db")
        self.engine = None
        self.coordinator = None
        self._lock = threading.Lock() # Fix for archive_context
        
        # Phase 11: Telemetry Shim for resilience in MCP tools
        if not hasattr(self.logger, "log_telemetry"):
            # Monkey-patch or attach shim to logger instance
            try:
                setattr(self.logger, "log_telemetry", lambda msg: self.logger.info(f"TELEMETRY: {msg}"))
            except (AttributeError, TypeError): pass

        if not HAS_PEEWEE:
            self.logger.warning("Peewee not installed. DB functions will be limited.")
            return

        self.db = SqliteDatabase(self.db_path, pragmas={
            'journal_mode': 'wal',
            'synchronous': 'normal',
            'mmap_size': 30000000000,
            'page_size': 65536,
            'busy_timeout': 30000,
            'cache_size': -100000,
            'foreign_keys': 1
        })
        self.db.connect(reuse_if_open=True)
        database_proxy.initialize(self.db)
        with self.db.atomic():
            init_schema(self.db.connection())
        
        self._init_mem_staging()

    def set_engine(self, engine):
        self.engine = engine

    def _init_mem_staging(self):
        try:
            conn = self.db.connection()
            conn.execute("ATTACH DATABASE ':memory:' AS staging_mem")
            conn.execute("CREATE TABLE IF NOT EXISTS staging_mem.files_temp AS SELECT * FROM main.files WHERE 0")
        except sqlite3.OperationalError: pass

    def ensure_root(self, root_id: str, path: str):
        with self.db.atomic():
            Root.insert(
                root_id=root_id, 
                root_path=path, 
                real_path=path,
                label=path.split("/")[-1]
            ).on_conflict_ignore().execute()
        self.db.commit()

    def upsert_files_turbo(self, rows: Iterable[tuple]):
        conn = self.db.connection()
        try:
            placeholders = ",".join(["?"] * 20)
            conn.executemany(f"INSERT OR REPLACE INTO staging_mem.files_temp VALUES ({placeholders})", rows)
        except sqlite3.OperationalError:
            self._init_mem_staging()
            conn.executemany(f"INSERT OR REPLACE INTO staging_mem.files_temp VALUES ({placeholders})", rows)

    def finalize_turbo_batch(self):
        conn = self.db.connection()
        try:
            conn.execute("BEGIN")
            conn.execute("INSERT OR REPLACE INTO main.files SELECT * FROM staging_mem.files_temp")
            conn.execute("DELETE FROM staging_mem.files_temp")
            conn.commit()
        except:
            conn.rollback()

    def count_failed_tasks(self) -> Tuple[int, int]:
        total = FailedTask.select().count()
        high = FailedTask.select().where(FailedTask.attempts >= 3).count()
        return total, high

    def upsert_symbols_tx(self, cur, rows: List[tuple], root_id: str = "root"):
        if not rows: return
        conn = self.db.connection()
        self.ensure_root(root_id, root_id)
        
        mapped_rows = []
        for r in rows:
            if not isinstance(r, (list, tuple)) or len(r) < 11: continue
            mapped = (r[10], r[0], root_id, r[1], r[2], r[3], r[4], r[5], r[6], r[7], r[8], r[9])
            mapped_rows.append(mapped)
            
        if not mapped_rows: return
        placeholders = ",".join(["?"] * 12)
        try:
            with self.db.atomic():
                conn.executemany(f"INSERT OR REPLACE INTO symbols VALUES ({placeholders})", mapped_rows)
        except Exception as e:
            if self.logger: self.logger.error(f"Failed to upsert symbols: {e}")
            raise

    def mark_deleted(self, path: str):
        ts = int(time.time())
        conn = self.db.connection()
        conn.execute("UPDATE files SET deleted_ts = ?, mtime = ? WHERE path = ?", (ts, ts, path))
        conn.execute("DELETE FROM symbols WHERE path = ?", (path,))
        conn.commit()

    def has_legacy_paths(self) -> bool: return False

    def get_repo_stats(self, root_ids: List[str] = None) -> Dict[str, int]:
        query = File.select(File.repo, fn.COUNT(File.path).alias('count')).where(File.deleted_ts == 0)
        if root_ids: query = query.where(File.root_id.in_(root_ids))
        results = query.group_by(File.repo).dicts()
        return {r['repo']: r['count'] for r in results}

    def get_roots(self) -> List[Dict[str, str]]:
        return list(Root.select().dicts())

    def upsert_root(self, root_id: str, path: str, real_path: str, label: str = ""):
        """Upsert a root record."""
        ts = int(time.time())
        sql = """INSERT OR REPLACE INTO roots (root_id, root_path, real_path, label, updated_ts, created_ts)
                 VALUES (?, ?, ?, ?, ?, ?)"""
        self.db.execute_sql(sql, (root_id, path, real_path, label, ts, ts))

    def ensure_root(self, root_id: str, path: str):
        """Ensure a root exists, if not create it."""
        if not Root.select().where(Root.root_id == root_id).exists():
            self.upsert_root(root_id, path, path)

    def _get_conn(self):
        return self.db.connection()

    @property
    def _read(self):
        conn = self.db.connection()
        conn.row_factory = sqlite3.Row
        return conn

    @property
    def _write(self):
        conn = self.db.connection()
        conn.row_factory = sqlite3.Row
        return conn

    def upsert_files_tx(self, cur, rows: Iterable[tuple]) -> int:
        """Upsert file records in a transaction."""
        from sari.core.utils.compression import _compress
        rows_list = []
        for r in rows:
            r_list = list(r)
            # Ensure enough columns for the new schema
            if len(r_list) < 20: 
                r_list.extend([None] * (20 - len(r_list)))
            
            raw_content = r_list[6] if isinstance(r_list[6], str) else ""
            compressed_content = _compress(raw_content)
            
            # (path, rel_path, root_id, repo, mtime, size, content, fts_content, last_seen, ...)
            rows_list.append((
                r_list[0], r_list[1], r_list[2], r_list[3], r_list[4], r_list[5],
                compressed_content, raw_content, # content, fts_content
                r_list[9], r_list[11], r_list[12], r_list[13], r_list[14],
                r_list[15], r_list[16], r_list[17], r_list[18], r_list[19]
            ))
            
        if not rows_list: return 0
        
        sql = """INSERT INTO files (path, rel_path, root_id, repo, mtime, size, content, fts_content, 
                                   last_seen, deleted_ts, parse_status, parse_reason, ast_status, ast_reason,
                                   is_binary, is_minified, sampled, content_bytes)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                 ON CONFLICT(path) DO UPDATE SET
                    repo=excluded.repo, mtime=excluded.mtime, size=excluded.size,
                    content=excluded.content, fts_content=excluded.fts_content,
                    last_seen=excluded.last_seen, deleted_ts=excluded.deleted_ts,
                    parse_status=excluded.parse_status, ast_status=excluded.ast_status
                 WHERE excluded.mtime >= files.mtime"""
        cur.executemany(sql, rows_list)
        return len(rows_list)

    def upsert_symbols_tx(self, cur, symbols: Iterable[tuple], **kwargs) -> int:
        """Upsert symbols in a transaction."""
        sym_list = list(symbols)
        if not sym_list: return 0
        
        # Sari V20 uses CompositeKey ('root_id', 'path', 'name', 'line')
        sql = """INSERT OR REPLACE INTO symbols 
                 (symbol_id, path, root_id, name, kind, line, end_line, content, parent_name, metadata, docstring, qualname)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        cur.executemany(sql, sym_list)
        return len(sym_list)

    def upsert_relations_tx(self, cur, relations: Iterable[tuple], **kwargs) -> int:
        """Upsert symbol relations in a transaction."""
        rels_list = list(relations)
        if not rels_list: return 0
        
        sql = """INSERT OR REPLACE INTO symbol_relations
                 (from_path, from_root_id, from_symbol, from_symbol_id, to_path, to_root_id, to_symbol, to_symbol_id, rel_type, line, metadata_json)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        cur.executemany(sql, rels_list)
        return len(rels_list)

    def upsert_context_tx(self, cur, context_rows: List[tuple]):
        """Save specialized context for RAG/Memory."""
        if not context_rows: return
        # Use placeholders for raw SQL
        sql = """INSERT OR REPLACE INTO contexts 
                 (topic, content, tags_json, related_files_json, source, valid_from, valid_until, deprecated, created_ts, updated_ts)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        cur.executemany(sql, context_rows)

    def search_symbols(self, query: str, limit: int = 50, root_ids: List[str] = None, repo: str = None, 
                       kinds: List[str] = None, path_prefix: str = None, match_mode: str = "contains", 
                       include_qualname: bool = True, case_sensitive: bool = False) -> List[Dict[str, Any]]:
        lq = query if match_mode == "exact" else (f"{query}%" if match_mode == "prefix" else f"%{query}%")
        # Fixed: Qualified root_id to avoid ambiguity when joining with files
        sql = "SELECT symbol_id, path, symbols.root_id, name, kind, line, end_line, qualname, repo FROM symbols JOIN files USING(path) WHERE deleted_ts = 0"
        params = []
        cmp = "name" if case_sensitive else "LOWER(name)"
        q_val = lq if case_sensitive else lq.lower()
        sql += f" AND ({cmp} LIKE ?"
        params.append(q_val)
        if include_qualname:
            qcmp = "qualname" if case_sensitive else "LOWER(qualname)"
            sql += f" OR {qcmp} LIKE ?"
            params.append(q_val)
        sql += ")"
        if root_ids:
            sql += " AND symbols.root_id IN (" + ",".join(["?"] * len(root_ids)) + ")"
            params.extend(root_ids)
        if repo:
            sql += " AND repo = ?"
            params.append(repo)
        if kinds:
            sql += " AND kind IN (" + ",".join(["?"] * len(kinds)) + ")"
            params.extend(kinds)
        if path_prefix:
            sql += " AND path LIKE ?"
            params.append(f"{path_prefix}%")
        sql += " LIMIT ?"
        params.append(limit)
        
        cursor = self.db.execute_sql(sql, params)
        results = []
        for r in cursor.fetchall():
            results.append({
                "symbol_id": r[0], "path": r[1], "root_id": r[2], "name": r[3],
                "kind": r[4], "line": r[5], "end_line": r[6], "qualname": r[7], "repo": r[8]
            })
        return results

    def get_symbol_block(self, path: str, name: str) -> Optional[str]:
        row = Symbol.select(Symbol.content).where((Symbol.path == path) & (Symbol.name == name)).first()
        if not row: return None
        data = row.content
        if isinstance(data, bytes) and data.startswith(b"ZLIB\0"):
            return zlib.decompress(data[5:]).decode("utf-8", errors="ignore")
        return data.decode("utf-8", errors="ignore") if isinstance(data, bytes) else data

    def search_files(self, query: str, limit: int = 50) -> List[Dict[str, Any]]:
        lq = f"%{query}%"
        return list(File.select().where((File.path ** lq) | (File.rel_path ** lq) | (File.fts_content ** lq)).limit(limit).dicts())

    def read_file(self, path: str) -> Optional[str]:
        row = File.select(File.content).where(File.path == path).first()
        if not row: return None
        data = row.content
        if isinstance(data, bytes) and data.startswith(b"ZLIB\0"):
            return zlib.decompress(data[5:]).decode("utf-8", errors="ignore")
        return data.decode("utf-8", errors="ignore") if isinstance(data, bytes) else data

    def list_files(self, limit: int = 50) -> List[Dict[str, Any]]:
        cursor = self.db.execute_sql("SELECT path, size, repo FROM files LIMIT ?", (limit,))
        return [{"path": r[0], "size": r[1], "repo": r[2]} for r in cursor.fetchall()]

    def prune_stale_data(self, root_id: str, active_paths: List[str]):
        with self.db.atomic():
            File.delete().where((File.root_id == root_id) & (File.path.not_in(active_paths))).execute()
            Symbol.delete().where(Symbol.path.not_in(active_paths)).execute()

    def repo_candidates(self, q: str, limit: int = 3, root_ids: Optional[List[str]] = None) -> List[Dict[str, Any]]:
        q = (q or "").strip()
        if not q: return []
        sql = "SELECT repo, COUNT(1) as c FROM files WHERE (path LIKE ? OR rel_path LIKE ?) AND deleted_ts = 0"
        params = [f"%{q}%", f"%{q}%"]
        if root_ids:
            sql += " AND root_id IN (" + ",".join(["?"] * len(root_ids)) + ")"
            params.extend(root_ids)
        sql += " GROUP BY repo ORDER BY c DESC LIMIT ?"
        params.append(limit)
        cursor = self.db.execute_sql(sql, params)
        return [{"repo": r[0], "score": int(r[1]), "evidence": ""} for r in cursor.fetchall()]

    def apply_root_filter(self, sql: str, root_id: Optional[str]) -> Tuple[str, List[Any]]:
        params = []
        if "WHERE" not in sql.upper():
            if root_id:
                sql += " WHERE root_id = ?"
                params.append(root_id)
            else: sql += " WHERE 1=1"
        else:
            if root_id:
                sql += " AND root_id = ?"
                params.append(root_id)
        return sql, params

    def search_api_endpoints(self, query: str, limit: int = 20) -> List[Dict[str, Any]]:
        return self.search_symbols(query, limit=limit, kinds=["method"], match_mode="contains")
        
    def get_callers(self, symbol_name: str, path: str) -> List[Dict[str, Any]]: return []
    def get_implementations(self, symbol_name: str, path: str) -> List[Dict[str, Any]]: return []
    def call_graph(self, symbol_name: str, depth: int = 2) -> Dict[str, Any]: return {"nodes": [], "edges": []}
    
    def list_snippets_by_tag(self, tag: str) -> List[Dict[str, Any]]:
        return list(Snippet.select().where(Snippet.tag == tag).dicts())

    def get_context_by_topic(self, topic: str) -> Optional[Dict[str, Any]]:
        row = Context.select().where(Context.topic == topic).first()
        return row.__data__ if row else None

    def register_writer_thread(self, *args, **kwargs): pass
    
    def close(self): self.db.close()
    def close_all(self): self.close()
