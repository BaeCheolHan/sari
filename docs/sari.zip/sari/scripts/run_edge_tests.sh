#!/usr/bin/env bash
set -euo pipefail

python3 -m pytest -q tests/test_edge_cases.py
